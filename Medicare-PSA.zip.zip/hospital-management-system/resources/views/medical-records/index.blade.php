@extends('layout')

@section('title', 'Medical Records - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Medical Records</h1>

    <p>
        Manage patient medical histories, diagnoses, treatments and clinical records.
    </p>

</div>


<!-- Summary Cards -->

<div style="
    display:grid;
    grid-template-columns:repeat(4, 1fr);
    gap:18px;
    margin-bottom:22px;
">


    <div class="stat">

        <div class="stat-icon">📋</div>

        <h4>Total Records</h4>

        <h2>1,284</h2>

        <span class="growth">
            All Patients
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">🩺</div>

        <h4>New Records</h4>

        <h2>32</h2>

        <span class="growth">
            This Week
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">🔬</div>

        <h4>Lab Reports</h4>

        <h2>86</h2>

        <span class="growth">
            Available
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">💊</div>

        <h4>Prescriptions</h4>

        <h2>214</h2>

        <span class="growth">
            This Month
        </span>

    </div>

</div>


<!-- Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:20px;
        flex-wrap:wrap;
    ">

        <div>

            <h3 style="
                color:#30245c;
                margin-bottom:6px;
            ">
                Patient Medical Records
            </h3>

            <p style="
                color:#827990;
                font-size:12px;
            ">
                Review and manage clinical information.
            </p>

        </div>


        <a href="/medical-records/create"
           style="
           background:#7357c7;
           color:white;
           padding:12px 20px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           ">
            + New Medical Record
        </a>

    </div>

</div>


<!-- Search -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        gap:12px;
        align-items:center;
    ">

        <input
            type="text"
            placeholder="Search patient, record ID or diagnosis..."
            style="
            flex:1;
            padding:12px 15px;
            border:1px solid #e5dfef;
            border-radius:8px;
            outline:none;
            "
        >


        <select style="
            padding:12px 18px;
            border:1px solid #e5dfef;
            border-radius:8px;
            outline:none;
            background:white;
        ">

            <option>All Records</option>
            <option>Recent</option>
            <option>Pending Review</option>
            <option>Completed</option>

        </select>


        <button style="
            background:#7357c7;
            color:white;
            border:none;
            padding:12px 20px;
            border-radius:8px;
            font-weight:bold;
        ">
            Search
        </button>

    </div>

</div>


<!-- Records Table -->

<div class="panel">

    <div class="panel-header">

        <h3>Recent Medical Records</h3>

        <span style="
            color:#827990;
            font-size:12px;
        ">
            Latest updates
        </span>

    </div>


    <table>

        <thead>

            <tr>

                <th>Record ID</th>

                <th>Patient</th>

                <th>Diagnosis</th>

                <th>Doctor</th>

                <th>Date</th>

                <th>Status</th>

                <th>Action</th>

            </tr>

        </thead>


        <tbody>


            <tr>

                <td>
                    MR-2048
                </td>

                <td class="doctor">
                    John Williams
                </td>

                <td>
                    Hypertension
                </td>

                <td>
                    Dr. Michael Brown
                </td>

                <td>
                    24 Aug 2026
                </td>

                <td>

                    <span class="badge confirmed">
                        Completed
                    </span>

                </td>

                <td>

                    <a href="/medical-records/1"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td>
                    MR-2047
                </td>

                <td class="doctor">
                    Sarah Johnson
                </td>

                <td>
                    Pediatric Fever
                </td>

                <td>
                    Dr. Emily Davis
                </td>

                <td>
                    23 Aug 2026
                </td>

                <td>

                    <span class="badge waiting">
                        Under Review
                    </span>

                </td>

                <td>

                    <a href="/medical-records/2"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td>
                    MR-2046
                </td>

                <td class="doctor">
                    David Anderson
                </td>

                <td>
                    Migraine
                </td>

                <td>
                    Dr. Robert Wilson
                </td>

                <td>
                    22 Aug 2026
                </td>

                <td>

                    <span class="badge confirmed">
                        Completed
                    </span>

                </td>

                <td>

                    <a href="/medical-records/3"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td>
                    MR-2045
                </td>

                <td class="doctor">
                    Mary Thompson
                </td>

                <td>
                    Joint Pain
                </td>

                <td>
                    Dr. Sarah Adams
                </td>

                <td>
                    21 Aug 2026
                </td>

                <td>

                    <span class="badge confirmed">
                        Completed
                    </span>

                </td>

                <td>

                    <a href="/medical-records/4"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td>
                    MR-2044
                </td>

                <td class="doctor">
                    James Wilson
                </td>

                <td>
                    Diabetes Review
                </td>

                <td>
                    Dr. Michael Brown
                </td>

                <td>
                    20 Aug 2026
                </td>

                <td>

                    <span class="badge waiting">
                        Pending
                    </span>

                </td>

                <td>

                    <a href="/medical-records/5"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


        </tbody>

    </table>

</div>

@endsection