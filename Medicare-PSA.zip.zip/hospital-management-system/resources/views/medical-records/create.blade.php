@extends('layout')

@section('title', 'New Medical Record - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>New Medical Record</h1>

    <p>
        Create and document a patient's clinical medical information.
    </p>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>Patient Information</h3>

        <a href="/medical-records">
            ← Back to Records
        </a>

    </div>


    <form action="#" method="POST">

        @csrf


        <!-- Patient Information -->

        <h3 style="
            color:#30245c;
            font-size:15px;
            margin-bottom:18px;
        ">
            Patient Details
        </h3>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        ">


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Select Patient
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select patient</option>
                    <option>PT-1001 - John Williams</option>
                    <option>PT-1002 - Sarah Johnson</option>
                    <option>PT-1003 - David Anderson</option>
                    <option>PT-1004 - Mary Thompson</option>
                    <option>PT-1005 - James Wilson</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Attending Doctor
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select doctor</option>
                    <option>Dr. Michael Brown</option>
                    <option>Dr. Emily Davis</option>
                    <option>Dr. Robert Wilson</option>
                    <option>Dr. Sarah Adams</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Record Date
                </label>

                <input
                    type="date"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Record Type
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select record type</option>
                    <option>General Consultation</option>
                    <option>Follow-up Examination</option>
                    <option>Emergency Visit</option>
                    <option>Laboratory Report</option>
                    <option>Prescription</option>

                </select>

            </div>

        </div>


        <!-- Clinical Information -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Clinical Information
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div style="grid-column:1 / 3;">

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Chief Complaint
                    </label>

                    <textarea
                        rows="4"
                        placeholder="Describe the patient's main complaint or reason for visit..."
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        resize:vertical;
                        "
                    ></textarea>

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Diagnosis
                    </label>

                    <input
                        type="text"
                        placeholder="Enter diagnosis"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Severity
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                    ">

                        <option>Select severity</option>
                        <option>Low</option>
                        <option>Moderate</option>
                        <option>High</option>
                        <option>Critical</option>

                    </select>

                </div>


                <div style="grid-column:1 / 3;">

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Clinical Notes
                    </label>

                    <textarea
                        rows="6"
                        placeholder="Enter examination findings, observations and clinical notes..."
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        resize:vertical;
                        "
                    ></textarea>

                </div>

            </div>

        </div>


        <!-- Treatment -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Treatment & Prescription
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div style="grid-column:1 / 3;">

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Treatment Plan
                    </label>

                    <textarea
                        rows="5"
                        placeholder="Enter recommended treatment and follow-up plan..."
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        resize:vertical;
                        "
                    ></textarea>

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Medication
                    </label>

                    <input
                        type="text"
                        placeholder="e.g. Medication name and dosage"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Follow-up Date
                    </label>

                    <input
                        type="date"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>

            </div>

        </div>


        <!-- Buttons -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
            display:flex;
            gap:10px;
        ">

            <button
                type="submit"
                style="
                background:#7357c7;
                color:white;
                border:none;
                padding:12px 24px;
                border-radius:9px;
                font-weight:bold;
                cursor:pointer;
                ">
                Save Medical Record
            </button>


            <a
                href="/medical-records"
                style="
                background:#f0ecfa;
                color:#6245b3;
                padding:12px 24px;
                border-radius:9px;
                text-decoration:none;
                font-weight:bold;
                ">
                Cancel
            </a>

        </div>

    </form>

</div>

@endsection