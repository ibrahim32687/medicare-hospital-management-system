@extends('layout')

@section('title', 'Medical Record Details - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Medical Record Details</h1>

    <p>
        View the patient's clinical history, diagnosis and treatment information.
    </p>

</div>


<!-- Record Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        flex-wrap:wrap;
        gap:20px;
    ">

        <div>

            <div style="
                display:flex;
                align-items:center;
                gap:10px;
                margin-bottom:7px;
            ">

                <h2 style="
                    color:#30245c;
                    margin:0;
                ">
                    Medical Record MR-2048
                </h2>

                <span class="badge confirmed">
                    Completed
                </span>

            </div>

            <p style="
                color:#827990;
                font-size:12px;
            ">
                Created on 24 August 2026
            </p>

        </div>


        <div style="
            display:flex;
            gap:10px;
        ">

            <a href="#"
               style="
               background:#f0ecfa;
               color:#6245b3;
               padding:11px 18px;
               border-radius:9px;
               text-decoration:none;
               font-size:13px;
               font-weight:bold;
               ">
                ✏️ Edit
            </a>


            <a href="/medical-records"
               style="
               background:#7357c7;
               color:white;
               padding:11px 18px;
               border-radius:9px;
               text-decoration:none;
               font-size:13px;
               font-weight:bold;
               ">
                ← All Records
            </a>

        </div>

    </div>

</div>


<!-- Main Layout -->

<div style="
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:22px;
">


    <!-- LEFT COLUMN -->

    <div>


        <!-- Patient -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Patient Information</h3>

                <a href="/patients/1">
                    View Patient →
                </a>

            </div>


            <div style="
                display:flex;
                align-items:center;
                gap:18px;
            ">

                <div style="
                    width:65px;
                    height:65px;
                    border-radius:50%;
                    background:#eee9fb;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:29px;
                ">
                    👤
                </div>


                <div>

                    <h3 style="
                        color:#403464;
                        margin-bottom:5px;
                    ">
                        John Williams
                    </h3>

                    <p style="
                        color:#827990;
                        font-size:12px;
                    ">
                        Patient ID: PT-1001
                    </p>

                </div>

            </div>


            <div style="
                display:grid;
                grid-template-columns:repeat(3, 1fr);
                gap:18px;
                margin-top:20px;
                padding-top:18px;
                border-top:1px solid #eeeaf3;
            ">


                <div>

                    <small style="color:#8c8497;">
                        Age
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        42 Years
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Gender
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        Male
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Blood Group
                    </small>

                    <p style="
                        color:#7357c7;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        O+
                    </p>

                </div>

            </div>

        </div>


        <!-- Clinical Information -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Clinical Information</h3>

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    General Consultation
                </span>

            </div>


            <div style="margin-bottom:22px;">

                <small style="color:#8c8497;">
                    Chief Complaint
                </small>

                <p style="
                    color:#403464;
                    font-size:13px;
                    line-height:1.7;
                    margin-top:7px;
                ">
                    Patient reported occasional headaches and
                    elevated blood pressure during the previous
                    two weeks.
                </p>

            </div>


            <div style="margin-bottom:22px;">

                <small style="color:#8c8497;">
                    Diagnosis
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    font-size:14px;
                    margin-top:7px;
                ">
                    Hypertension
                </p>

            </div>


            <div>

                <small style="color:#8c8497;">
                    Clinical Notes
                </small>

                <p style="
                    color:#403464;
                    font-size:13px;
                    line-height:1.8;
                    margin-top:7px;
                ">
                    Patient was examined and blood pressure
                    readings were reviewed. Lifestyle modification,
                    regular monitoring and follow-up consultation
                    were recommended.
                </p>

            </div>

        </div>


        <!-- Treatment -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Treatment Plan</h3>

            </div>


            <div style="
                background:#faf9fc;
                padding:18px;
                border-radius:10px;
                margin-bottom:18px;
            ">

                <small style="color:#8c8497;">
                    Recommended Treatment
                </small>

                <p style="
                    color:#403464;
                    font-size:13px;
                    line-height:1.8;
                    margin-top:7px;
                ">
                    Continue regular blood pressure monitoring,
                    maintain a balanced diet, exercise regularly
                    and attend the scheduled follow-up consultation.
                </p>

            </div>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:18px;
            ">

                <div>

                    <small style="color:#8c8497;">
                        Medication
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        Prescribed medication
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Follow-up Date
                    </small>

                    <p style="
                        color:#7357c7;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        07 September 2026
                    </p>

                </div>

            </div>

        </div>


        <!-- Medical History -->

        <div class="panel">

            <div class="panel-header">

                <h3>Recent Medical History</h3>

                <a href="#">
                    View Full History
                </a>

            </div>


            <table>

                <thead>

                    <tr>

                        <th>Date</th>

                        <th>Diagnosis</th>

                        <th>Doctor</th>

                        <th>Status</th>

                    </tr>

                </thead>


                <tbody>

                    <tr>

                        <td>
                            24 Aug 2026
                        </td>

                        <td class="doctor">
                            Hypertension
                        </td>

                        <td>
                            Dr. Michael Brown
                        </td>

                        <td>

                            <span class="badge confirmed">
                                Completed
                            </span>

                        </td>

                    </tr>


                    <tr>

                        <td>
                            12 Jul 2026
                        </td>

                        <td class="doctor">
                            Headache
                        </td>

                        <td>
                            Dr. Michael Brown
                        </td>

                        <td>

                            <span class="badge confirmed">
                                Completed
                            </span>

                        </td>

                    </tr>


                    <tr>

                        <td>
                            08 Jun 2026
                        </td>

                        <td class="doctor">
                            Routine Check-up
                        </td>

                        <td>
                            Dr. Emily Davis
                        </td>

                        <td>

                            <span class="badge confirmed">
                                Completed
                            </span>

                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>


    <!-- RIGHT COLUMN -->

    <div>


        <!-- Doctor -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Attending Doctor</h3>

            </div>


            <div style="
                text-align:center;
                padding:10px 0 20px;
            ">

                <div style="
                    width:70px;
                    height:70px;
                    border-radius:50%;
                    background:#eee9fb;
                    margin:auto;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:31px;
                ">
                    👨‍⚕️
                </div>


                <h3 style="
                    color:#403464;
                    margin-top:12px;
                ">
                    Dr. Michael Brown
                </h3>


                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:5px;
                ">
                    Consultant Cardiologist
                </p>

            </div>


            <div style="
                padding-top:15px;
                border-top:1px solid #eeeaf3;
            ">

                <small style="color:#8c8497;">
                    Department
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:5px;
                ">
                    Cardiology
                </p>

            </div>

        </div>


        <!-- Record Information -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Record Information</h3>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Record ID
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    MR-2048
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Record Type
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    Consultation
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Created
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    24 Aug 2026
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Status
                </span>

                <span class="badge confirmed">
                    Completed
                </span>

            </div>

        </div>


        <!-- Quick Actions -->

        <div class="panel">

            <div class="panel-header">

                <h3>Quick Actions</h3>

            </div>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                📄 Print Record
            </a>


            <a href="/appointments"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                📅 View Appointments
            </a>


            <a href="/medical-records"
               style="
               display:block;
               padding:13px;
               background:#7357c7;
               color:white;
               text-decoration:none;
               border-radius:8px;
               font-size:13px;
               font-weight:bold;
               text-align:center;
               ">
                ← All Medical Records
            </a>

        </div>

    </div>

</div>

@endsection