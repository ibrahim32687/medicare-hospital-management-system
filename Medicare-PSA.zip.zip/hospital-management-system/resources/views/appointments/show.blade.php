@extends('layout')

@section('title', 'Appointment Details - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Appointment Details</h1>

    <p>
        View the complete information for a scheduled appointment.
    </p>

</div>


<!-- Appointment Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        flex-wrap:wrap;
        gap:20px;
    ">

        <div>

            <div style="
                display:flex;
                align-items:center;
                gap:12px;
                margin-bottom:8px;
            ">

                <h2 style="
                    color:#30245c;
                    margin:0;
                ">
                    General Consultation
                </h2>

                <span class="badge confirmed">
                    Confirmed
                </span>

            </div>

            <p style="
                color:#827990;
                font-size:13px;
            ">
                Appointment ID: AP-2026-0048
            </p>

        </div>


        <a href="/appointments"
           style="
           background:#f0ecfa;
           color:#6245b3;
           padding:11px 18px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           ">
            ← Back to Schedule
        </a>

    </div>

</div>


<!-- Main Content -->

<div style="
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:22px;
">


    <!-- LEFT -->

    <div>


        <!-- Date & Time -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Date & Time</h3>

            </div>


            <div style="
                display:grid;
                grid-template-columns:repeat(3, 1fr);
                gap:18px;
            ">


                <div style="
                    background:#faf9fc;
                    padding:18px;
                    border-radius:10px;
                ">

                    <small style="color:#8c8497;">
                        Date
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:7px;
                    ">
                        24 August 2026
                    </p>

                </div>


                <div style="
                    background:#faf9fc;
                    padding:18px;
                    border-radius:10px;
                ">

                    <small style="color:#8c8497;">
                        Start Time
                    </small>

                    <p style="
                        color:#7357c7;
                        font-weight:bold;
                        margin-top:7px;
                    ">
                        09:00 AM
                    </p>

                </div>


                <div style="
                    background:#faf9fc;
                    padding:18px;
                    border-radius:10px;
                ">

                    <small style="color:#8c8497;">
                        Duration
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:7px;
                    ">
                        30 Minutes
                    </p>

                </div>

            </div>

        </div>


        <!-- Patient Information -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Patient Information</h3>

                <a href="/patients/1">
                    View Patient →
                </a>

            </div>


            <div style="
                display:flex;
                align-items:center;
                gap:18px;
            ">

                <div style="
                    width:65px;
                    height:65px;
                    border-radius:50%;
                    background:#eee9fb;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:30px;
                ">
                    👤
                </div>


                <div>

                    <h3 style="
                        color:#403464;
                        margin-bottom:5px;
                    ">
                        John Williams
                    </h3>

                    <p style="
                        color:#827990;
                        font-size:12px;
                    ">
                        Patient ID: PT-1001
                    </p>

                </div>

            </div>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr 1fr;
                gap:18px;
                margin-top:22px;
                padding-top:20px;
                border-top:1px solid #eeeaf3;
            ">


                <div>

                    <small style="color:#8c8497;">
                        Age
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        42 Years
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Gender
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        Male
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Blood Group
                    </small>

                    <p style="
                        color:#7357c7;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        O+
                    </p>

                </div>

            </div>

        </div>


        <!-- Doctor Information -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Doctor Information</h3>

                <a href="/doctors/1">
                    View Doctor →
                </a>

            </div>


            <div style="
                display:flex;
                align-items:center;
                gap:18px;
            ">

                <div style="
                    width:65px;
                    height:65px;
                    border-radius:50%;
                    background:#eee9fb;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:30px;
                ">
                    👨‍⚕️
                </div>


                <div>

                    <h3 style="
                        color:#403464;
                        margin-bottom:5px;
                    ">
                        Dr. Michael Brown
                    </h3>

                    <p style="
                        color:#827990;
                        font-size:12px;
                    ">
                        Consultant Cardiologist
                    </p>

                </div>

            </div>


            <div style="
                margin-top:20px;
                padding-top:18px;
                border-top:1px solid #eeeaf3;
            ">

                <small style="color:#8c8497;">
                    Department
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:5px;
                ">
                    Cardiology
                </p>

            </div>

        </div>


        <!-- Notes -->

        <div class="panel">

            <div class="panel-header">

                <h3>Appointment Notes</h3>

            </div>


            <p style="
                color:#827990;
                font-size:13px;
                line-height:1.8;
            ">
                Patient is scheduled for a general cardiovascular
                consultation and routine health assessment.
                Previous medical records should be reviewed
                before the consultation.
            </p>

        </div>

    </div>


    <!-- RIGHT -->

    <div>


        <!-- Status -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Appointment Status</h3>

            </div>


            <div style="
                text-align:center;
                padding:15px 0 20px;
            ">

                <div style="
                    width:70px;
                    height:70px;
                    border-radius:50%;
                    background:#eee9fb;
                    margin:auto;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:30px;
                ">
                    ✓
                </div>


                <h3 style="
                    color:#403464;
                    margin-top:12px;
                ">
                    Confirmed
                </h3>


                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:5px;
                ">
                    Appointment is confirmed.
                </p>

            </div>

        </div>


        <!-- Quick Actions -->

        <div class="panel">

            <div class="panel-header">

                <h3>Quick Actions</h3>

            </div>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                ✏️ Edit Appointment
            </a>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                ✓ Mark as Completed
            </a>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#fff3f3;
               color:#c04a4a;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                ✕ Cancel Appointment
            </a>


            <a href="/appointments"
               style="
               display:block;
               padding:13px;
               background:#7357c7;
               color:white;
               text-decoration:none;
               border-radius:8px;
               font-size:13px;
               font-weight:bold;
               text-align:center;
               ">
                ← Appointment Schedule
            </a>

        </div>

    </div>

</div>

@endsection