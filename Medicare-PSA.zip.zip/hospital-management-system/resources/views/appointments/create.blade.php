@extends('layout')

@section('title', 'New Appointment - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>New Appointment</h1>

    <p>
        Schedule a consultation or medical appointment for a patient.
    </p>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>Appointment Details</h3>

        <a href="/appointments">
            ← Back to Schedule
        </a>

    </div>


    <form action="#" method="POST">

        @csrf


        <!-- Patient & Doctor -->

        <h3 style="
            color:#30245c;
            font-size:15px;
            margin-bottom:18px;
        ">
            Patient & Doctor
        </h3>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        ">


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Select Patient
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select patient</option>
                    <option>PT-1001 - John Williams</option>
                    <option>PT-1002 - Sarah Johnson</option>
                    <option>PT-1003 - David Anderson</option>
                    <option>PT-1004 - Mary Thompson</option>
                    <option>PT-1005 - James Wilson</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Select Doctor
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select doctor</option>
                    <option>Dr. Michael Brown</option>
                    <option>Dr. Emily Davis</option>
                    <option>Dr. Robert Wilson</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Department
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select department</option>
                    <option>Cardiology</option>
                    <option>Pediatrics</option>
                    <option>Neurology</option>
                    <option>Orthopedics</option>
                    <option>General Medicine</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Appointment Type
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select appointment type</option>
                    <option>General Consultation</option>
                    <option>Follow-up</option>
                    <option>Medical Check-up</option>
                    <option>Emergency Consultation</option>
                    <option>Specialist Consultation</option>

                </select>

            </div>

        </div>


        <!-- Date & Time -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Date & Time
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr 1fr;
                gap:20px;
            ">


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Appointment Date
                    </label>

                    <input
                        type="date"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Start Time
                    </label>

                    <input
                        type="time"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Duration
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                    ">

                        <option>30 Minutes</option>
                        <option>45 Minutes</option>
                        <option>60 Minutes</option>
                        <option>90 Minutes</option>

                    </select>

                </div>

            </div>

        </div>


        <!-- Notes -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Appointment Notes
            </h3>


            <textarea
                rows="5"
                placeholder="Enter reason for appointment or additional notes..."
                style="
                width:100%;
                padding:12px;
                border:1px solid #e5dfef;
                border-radius:8px;
                outline:none;
                resize:vertical;
                "
            ></textarea>

        </div>


        <!-- Buttons -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
            display:flex;
            gap:10px;
        ">

            <button
                type="submit"
                style="
                background:#7357c7;
                color:white;
                border:none;
                padding:12px 24px;
                border-radius:9px;
                font-weight:bold;
                cursor:pointer;
                ">
                Schedule Appointment
            </button>


            <a
                href="/appointments"
                style="
                background:#f0ecfa;
                color:#6245b3;
                padding:12px 24px;
                border-radius:9px;
                text-decoration:none;
                font-weight:bold;
                ">
                Cancel
            </a>

        </div>

    </form>

</div>

@endsection