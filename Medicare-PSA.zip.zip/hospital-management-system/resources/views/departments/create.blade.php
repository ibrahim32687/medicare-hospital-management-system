@extends('layout')

@section('title', 'Add Department - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Add New Department</h1>

    <p>
        Create a new department and configure its basic information.
    </p>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>Department Information</h3>

        <a href="/departments">
            ← Back to Departments
        </a>

    </div>


    <form action="#" method="POST">

        @csrf


        <!-- Basic Information -->

        <h3 style="
            color:#30245c;
            font-size:15px;
            margin-bottom:18px;
        ">
            Basic Information
        </h3>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        ">


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Department Name
                </label>

                <input
                    type="text"
                    placeholder="e.g. Cardiology"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Department Code
                </label>

                <input
                    type="text"
                    placeholder="e.g. CARD-01"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div style="grid-column:1 / 3;">

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Department Description
                </label>

                <textarea
                    rows="5"
                    placeholder="Describe the services and responsibilities of this department..."
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    resize:vertical;
                    "
                ></textarea>

            </div>

        </div>


        <!-- Department Configuration -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Department Configuration
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Department Head
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                    ">

                        <option>Select department head</option>
                        <option>Dr. Michael Brown</option>
                        <option>Dr. Emily Davis</option>
                        <option>Dr. Robert Wilson</option>

                    </select>

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Number of Beds
                    </label>

                    <input
                        type="number"
                        placeholder="e.g. 25"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Department Location
                    </label>

                    <input
                        type="text"
                        placeholder="e.g. Block A, Floor 2"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Department Status
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                    ">

                        <option>Active</option>
                        <option>Inactive</option>

                    </select>

                </div>

            </div>

        </div>


        <!-- Contact Information -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Contact Information
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Department Phone
                    </label>

                    <input
                        type="text"
                        placeholder="Enter department phone"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Department Email
                    </label>

                    <input
                        type="email"
                        placeholder="department@medicare.com"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>

            </div>

        </div>


        <!-- Buttons -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
            display:flex;
            gap:10px;
        ">

            <button
                type="submit"
                style="
                background:#7357c7;
                color:white;
                border:none;
                padding:12px 24px;
                border-radius:9px;
                font-weight:bold;
                cursor:pointer;
                ">
                Create Department
            </button>


            <a
                href="/departments"
                style="
                background:#f0ecfa;
                color:#6245b3;
                padding:12px 24px;
                border-radius:9px;
                text-decoration:none;
                font-weight:bold;
                ">
                Cancel
            </a>

        </div>

    </form>

</div>

@endsection