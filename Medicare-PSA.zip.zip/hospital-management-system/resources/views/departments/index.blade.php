@extends('layout')

@section('title', 'Departments - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Hospital Departments</h1>

    <p>
        Manage hospital departments, medical teams and available services.
    </p>

</div>


<!-- Top Summary -->

<div style="
    display:grid;
    grid-template-columns:repeat(3, 1fr);
    gap:18px;
    margin-bottom:22px;
">


    <div class="stat">

        <div class="stat-icon">🏥</div>

        <h4>Total Departments</h4>

        <h2>8</h2>

        <span class="growth">
            Active
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">👨‍⚕️</div>

        <h4>Medical Staff</h4>

        <h2>42</h2>

        <span class="growth">
            Doctors
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">🛏️</div>

        <h4>Available Beds</h4>

        <h2>126</h2>

        <span class="growth">
            Available
        </span>

    </div>

</div>


<!-- Department Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:20px;
    ">

        <div>

            <h3 style="
                color:#30245c;
                margin-bottom:6px;
            ">
                Medical Departments
            </h3>

            <p style="
                color:#827990;
                font-size:12px;
            ">
                Select a department to view detailed information.
            </p>

        </div>


        <a href="/departments/create"
           style="
           background:#7357c7;
           color:white;
           padding:12px 20px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           ">
            + Add Department
        </a>

    </div>

</div>


<!-- Department Cards -->

<div style="
    display:grid;
    grid-template-columns:repeat(2, 1fr);
    gap:20px;
">


    <!-- Cardiology -->

    <div class="panel">

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
        ">

            <div style="
                width:55px;
                height:55px;
                border-radius:12px;
                background:#eee9fb;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:27px;
            ">
                ❤️
            </div>


            <span class="badge confirmed">
                Active
            </span>

        </div>


        <h3 style="
            color:#403464;
            margin-top:18px;
        ">
            Cardiology
        </h3>


        <p style="
            color:#827990;
            font-size:12px;
            line-height:1.7;
            margin-top:7px;
        ">
            Specialized care for heart and cardiovascular
            conditions.
        </p>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:10px;
            margin-top:18px;
            padding-top:15px;
            border-top:1px solid #eeeaf3;
        ">

            <div>

                <small style="color:#8c8497;">
                    Doctors
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    8
                </p>

            </div>


            <div>

                <small style="color:#8c8497;">
                    Beds
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    24
                </p>

            </div>

        </div>


        <a href="/departments/1"
           style="
           display:block;
           text-align:center;
           margin-top:18px;
           padding:10px;
           background:#f5f1fc;
           color:#6245b3;
           border-radius:8px;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Department →
        </a>

    </div>


    <!-- Neurology -->

    <div class="panel">

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
        ">

            <div style="
                width:55px;
                height:55px;
                border-radius:12px;
                background:#eee9fb;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:27px;
            ">
                🧠
            </div>


            <span class="badge confirmed">
                Active
            </span>

        </div>


        <h3 style="
            color:#403464;
            margin-top:18px;
        ">
            Neurology
        </h3>


        <p style="
            color:#827990;
            font-size:12px;
            line-height:1.7;
            margin-top:7px;
        ">
            Diagnosis and treatment of disorders affecting
            the nervous system.
        </p>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:10px;
            margin-top:18px;
            padding-top:15px;
            border-top:1px solid #eeeaf3;
        ">

            <div>

                <small style="color:#8c8497;">
                    Doctors
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    6
                </p>

            </div>


            <div>

                <small style="color:#8c8497;">
                    Beds
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    18
                </p>

            </div>

        </div>


        <a href="/departments/2"
           style="
           display:block;
           text-align:center;
           margin-top:18px;
           padding:10px;
           background:#f5f1fc;
           color:#6245b3;
           border-radius:8px;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Department →
        </a>

    </div>


    <!-- Pediatrics -->

    <div class="panel">

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
        ">

            <div style="
                width:55px;
                height:55px;
                border-radius:12px;
                background:#eee9fb;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:27px;
            ">
                👶
            </div>


            <span class="badge confirmed">
                Active
            </span>

        </div>


        <h3 style="
            color:#403464;
            margin-top:18px;
        ">
            Pediatrics
        </h3>


        <p style="
            color:#827990;
            font-size:12px;
            line-height:1.7;
            margin-top:7px;
        ">
            Medical care and treatment specifically designed
            for children.
        </p>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:10px;
            margin-top:18px;
            padding-top:15px;
            border-top:1px solid #eeeaf3;
        ">

            <div>

                <small style="color:#8c8497;">
                    Doctors
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    7
                </p>

            </div>


            <div>

                <small style="color:#8c8497;">
                    Beds
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    20
                </p>

            </div>

        </div>


        <a href="/departments/3"
           style="
           display:block;
           text-align:center;
           margin-top:18px;
           padding:10px;
           background:#f5f1fc;
           color:#6245b3;
           border-radius:8px;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Department →
        </a>

    </div>


    <!-- Orthopedics -->

    <div class="panel">

        <div style="
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
        ">

            <div style="
                width:55px;
                height:55px;
                border-radius:12px;
                background:#eee9fb;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:27px;
            ">
                🦴
            </div>


            <span class="badge confirmed">
                Active
            </span>

        </div>


        <h3 style="
            color:#403464;
            margin-top:18px;
        ">
            Orthopedics
        </h3>


        <p style="
            color:#827990;
            font-size:12px;
            line-height:1.7;
            margin-top:7px;
        ">
            Treatment of bones, joints, muscles and other
            musculoskeletal conditions.
        </p>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:10px;
            margin-top:18px;
            padding-top:15px;
            border-top:1px solid #eeeaf3;
        ">

            <div>

                <small style="color:#8c8497;">
                    Doctors
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    5
                </p>

            </div>


            <div>

                <small style="color:#8c8497;">
                    Beds
                </small>

                <p style="
                    color:#403464;
                    font-weight:bold;
                    margin-top:4px;
                ">
                    16
                </p>

            </div>

        </div>


        <a href="/departments/4"
           style="
           display:block;
           text-align:center;
           margin-top:18px;
           padding:10px;
           background:#f5f1fc;
           color:#6245b3;
           border-radius:8px;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Department →
        </a>

    </div>


</div>

@endsection