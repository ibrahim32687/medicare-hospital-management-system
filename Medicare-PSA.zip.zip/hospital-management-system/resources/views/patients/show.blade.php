@extends('layout')

@section('title', 'Patient Profile - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Patient Profile</h1>

    <p>
        View patient information, medical history and current status.
    </p>

</div>


<!-- Patient Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        flex-wrap:wrap;
        gap:20px;
    ">

        <div style="
            display:flex;
            align-items:center;
            gap:18px;
        ">

            <div style="
                width:75px;
                height:75px;
                border-radius:50%;
                background:#eee9fb;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:35px;
            ">
                👤
            </div>


            <div>

                <h2 style="
                    color:#30245c;
                    margin-bottom:6px;
                ">
                    John Williams
                </h2>

                <p style="
                    color:#827990;
                    font-size:13px;
                    margin-bottom:7px;
                ">
                    Patient ID: PT-1001
                </p>

                <span class="badge confirmed">
                    Active Patient
                </span>

            </div>

        </div>


        <a href="/patients"
           style="
           background:#f0ecfa;
           color:#6245b3;
           padding:11px 18px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           ">
            ← Back to Patients
        </a>

    </div>

</div>


<!-- Main Information -->

<div style="
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:22px;
">


    <!-- LEFT SIDE -->

    <div>


        <!-- Personal Information -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Personal Information</h3>

                <a href="#">
                    Edit Profile
                </a>

            </div>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr 1fr;
                gap:22px;
            ">


                <div>

                    <small style="color:#8c8497;">
                        Full Name
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        John Williams
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Date of Birth
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        15 March 1984
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Age
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        42 Years
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Gender
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        Male
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Blood Group
                    </small>

                    <p style="
                        color:#7357c7;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        O+
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Phone
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        +234 802 456 7812
                    </p>

                </div>


            </div>

        </div>


        <!-- Medical History -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Medical History</h3>

                <a href="#">
                    View Full History →
                </a>

            </div>


            <table>

                <thead>

                    <tr>
                        <th>Date</th>
                        <th>Condition</th>
                        <th>Doctor</th>
                        <th>Status</th>
                    </tr>

                </thead>


                <tbody>


                    <tr>

                        <td>12 Aug 2026</td>

                        <td class="patient">
                            Heart Check-up
                        </td>

                        <td class="doctor">
                            Dr. Michael Brown
                        </td>

                        <td>
                            <span class="badge confirmed">
                                Completed
                            </span>
                        </td>

                    </tr>


                    <tr>

                        <td>03 Jun 2026</td>

                        <td class="patient">
                            Blood Pressure
                        </td>

                        <td class="doctor">
                            Dr. Michael Brown
                        </td>

                        <td>
                            <span class="badge confirmed">
                                Completed
                            </span>
                        </td>

                    </tr>


                    <tr>

                        <td>18 Feb 2026</td>

                        <td class="patient">
                            General Consultation
                        </td>

                        <td class="doctor">
                            Dr. Emily Davis
                        </td>

                        <td>
                            <span class="badge confirmed">
                                Completed
                            </span>
                        </td>

                    </tr>


                </tbody>

            </table>

        </div>


        <!-- Current Treatment -->

        <div class="panel">

            <div class="panel-header">

                <h3>Current Treatment</h3>

            </div>


            <div style="
                background:#faf9fc;
                border-radius:10px;
                padding:18px;
                margin-bottom:12px;
            ">

                <strong style="
                    color:#403464;
                    font-size:13px;
                ">
                    Cardiovascular Monitoring
                </strong>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:7px;
                    line-height:1.6;
                ">
                    Regular blood pressure monitoring and
                    cardiovascular assessment.
                </p>

            </div>


            <div style="
                background:#faf9fc;
                border-radius:10px;
                padding:18px;
            ">

                <strong style="
                    color:#403464;
                    font-size:13px;
                ">
                    Follow-up Appointment
                </strong>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:7px;
                ">
                    Next appointment: 28 August 2026
                </p>

            </div>

        </div>

    </div>


    <!-- RIGHT SIDE -->

    <div>


        <!-- Contact -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Contact</h3>

            </div>


            <div style="
                padding:14px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <small style="color:#8c8497;">
                    Email
                </small>

                <p style="
                    color:#403464;
                    font-size:13px;
                    margin-top:6px;
                ">
                    john.williams@example.com
                </p>

            </div>


            <div style="
                padding:14px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <small style="color:#8c8497;">
                    Address
                </small>

                <p style="
                    color:#403464;
                    font-size:13px;
                    margin-top:6px;
                    line-height:1.6;
                ">
                    25 Independence Avenue,
                    Abuja, Nigeria
                </p>

            </div>


            <div style="padding:14px 0;">

                <small style="color:#8c8497;">
                    Emergency Contact
                </small>

                <p style="
                    color:#403464;
                    font-size:13px;
                    margin-top:6px;
                ">
                    Sarah Williams
                </p>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:4px;
                ">
                    +234 803 456 9901
                </p>

            </div>

        </div>


        <!-- Quick Actions -->

        <div class="panel">

            <div class="panel-header">

                <h3>Quick Actions</h3>

            </div>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                📅 Schedule Appointment
            </a>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                💊 View Prescriptions
            </a>


            <a href="#"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                🧾 View Billing
            </a>


            <a href="/patients"
               style="
               display:block;
               padding:13px;
               background:#7357c7;
               color:white;
               text-decoration:none;
               border-radius:8px;
               font-size:13px;
               font-weight:bold;
               text-align:center;
               ">
                ← Patient Directory
            </a>

        </div>

    </div>

</div>

@endsection