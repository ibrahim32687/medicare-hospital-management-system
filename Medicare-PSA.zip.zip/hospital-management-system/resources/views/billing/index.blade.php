@extends('layout')

@section('title', 'Billing - MediCare Hospital')

@section('content')

<div class="page-heading">

    <h1>Billing & Payments</h1>

    <p>
        Manage patient invoices, payments, outstanding balances and billing records.
    </p>

</div>


<!-- Financial Summary -->

<div style="
    display:grid;
    grid-template-columns:repeat(4, 1fr);
    gap:18px;
    margin-bottom:22px;
">


    <div class="stat">

        <div class="stat-icon">💰</div>

        <h4>Total Revenue</h4>

        <h2>₦8.42M</h2>

        <span class="growth">
            This Month
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">✓</div>

        <h4>Paid Invoices</h4>

        <h2>386</h2>

        <span class="growth">
            Successfully Paid
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">⏳</div>

        <h4>Pending Payments</h4>

        <h2>47</h2>

        <span class="growth">
            Awaiting Payment
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">⚠️</div>

        <h4>Outstanding</h4>

        <h2>₦1.28M</h2>

        <span class="growth">
            Unpaid Balance
        </span>

    </div>

</div>


<!-- Billing Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:20px;
        flex-wrap:wrap;
    ">

        <div>

            <h3 style="
                color:#30245c;
                margin-bottom:6px;
            ">
                Patient Invoices
            </h3>

            <p style="
                color:#827990;
                font-size:12px;
            ">
                Track invoices and payment status.
            </p>

        </div>


        <a href="/billing/create"
           style="
           background:#7357c7;
           color:white;
           padding:12px 20px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           ">
            + Create Invoice
        </a>

    </div>

</div>


<!-- Billing Filters -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        gap:12px;
        align-items:center;
        flex-wrap:wrap;
    ">


        <input
            type="text"
            placeholder="Search invoice or patient..."
            style="
            flex:1;
            min-width:220px;
            padding:12px 15px;
            border:1px solid #e5dfef;
            border-radius:8px;
            outline:none;
            "
        >


        <select style="
            padding:12px 18px;
            border:1px solid #e5dfef;
            border-radius:8px;
            outline:none;
            background:white;
        ">

            <option>All Status</option>
            <option>Paid</option>
            <option>Pending</option>
            <option>Overdue</option>

        </select>


        <select style="
            padding:12px 18px;
            border:1px solid #e5dfef;
            border-radius:8px;
            outline:none;
            background:white;
        ">

            <option>This Month</option>
            <option>Last Month</option>
            <option>This Year</option>

        </select>


        <button style="
            background:#7357c7;
            color:white;
            border:none;
            padding:12px 20px;
            border-radius:8px;
            font-weight:bold;
        ">
            Search
        </button>

    </div>

</div>


<!-- Invoice Table -->

<div class="panel">

    <div class="panel-header">

        <h3>Recent Invoices</h3>

        <span style="
            color:#827990;
            font-size:12px;
        ">
            Latest billing activity
        </span>

    </div>


    <table>

        <thead>

            <tr>

                <th>Invoice</th>

                <th>Patient</th>

                <th>Service</th>

                <th>Amount</th>

                <th>Date</th>

                <th>Status</th>

                <th>Action</th>

            </tr>

        </thead>


        <tbody>


            <tr>

                <td class="doctor">
                    INV-3048
                </td>

                <td>
                    John Williams
                </td>

                <td>
                    Consultation
                </td>

                <td>
                    ₦45,000
                </td>

                <td>
                    24 Aug 2026
                </td>

                <td>

                    <span class="badge confirmed">
                        Paid
                    </span>

                </td>

                <td>

                    <a href="/billing/1"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td class="doctor">
                    INV-3047
                </td>

                <td>
                    Sarah Johnson
                </td>

                <td>
                    Laboratory Test
                </td>

                <td>
                    ₦28,500
                </td>

                <td>
                    23 Aug 2026
                </td>

                <td>

                    <span class="badge waiting">
                        Pending
                    </span>

                </td>

                <td>

                    <a href="/billing/2"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td class="doctor">
                    INV-3046
                </td>

                <td>
                    David Anderson
                </td>

                <td>
                    Pharmacy
                </td>

                <td>
                    ₦18,750
                </td>

                <td>
                    22 Aug 2026
                </td>

                <td>

                    <span class="badge confirmed">
                        Paid
                    </span>

                </td>

                <td>

                    <a href="/billing/3"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td class="doctor">
                    INV-3045
                </td>

                <td>
                    Mary Thompson
                </td>

                <td>
                    Hospital Admission
                </td>

                <td>
                    ₦125,000
                </td>

                <td>
                    21 Aug 2026
                </td>

                <td>

                    <span class="badge waiting">
                        Pending
                    </span>

                </td>

                <td>

                    <a href="/billing/4"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


            <tr>

                <td class="doctor">
                    INV-3044
                </td>

                <td>
                    James Wilson
                </td>

                <td>
                    Medical Consultation
                </td>

                <td>
                    ₦35,000
                </td>

                <td>
                    20 Aug 2026
                </td>

                <td>

                    <span class="badge confirmed">
                        Paid
                    </span>

                </td>

                <td>

                    <a href="/billing/5"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-weight:bold;
                       ">
                        View →
                    </a>

                </td>

            </tr>


        </tbody>

    </table>

</div>

@endsection