<?php

use Illuminate\Support\Facades\Route;

Route::get('/dashboard', function () {
    return view('dashboard.index');
});
Route::get('/doctors', function () {
    return view('doctors.index');
});
Route::get('/doctors/create', function () {
    return view('doctors.create');
});
Route::get('/patients', function () {
    return view('patients.index');
});
Route::get('/patients/create', function () {
    return view('patients.create');
});
Route::get('/patients/{id}', function ($id) {
    return view('patients.show');
});
Route::get('/appointments', function () {
    return view('appointments.index');
});
Route::get('/appointments/create', function () {
    return view('appointments.create');
});
Route::get('/appointments/{id}', function ($id) {
    return view('appointments.show');
});
Route::get('/departments', function () {
    return view('departments.index');
});
Route::get('/departments/create', function () {
    return view('departments.create');
});
Route::get('/departments/{id}', function ($id) {
    return view('departments.show');
});
Route::get('/medical-records', function () {
    return view('medical-records.index');
});
Route::get('/medical-records/create', function () {
    return view('medical-records.create');
});
Route::get('/medical-records/{id}', function ($id) {
    return view('medical-records.show');
});
Route::get('/billing', function () {
    return view('billing.index');
});
Route::get('/billing/create', function () {
    return view('billing.create');
});
Route::get('/billing/{id}', function ($id) {
    return view('billing.show');
});