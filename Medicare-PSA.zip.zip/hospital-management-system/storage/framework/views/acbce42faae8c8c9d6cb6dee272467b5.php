

<?php $__env->startSection('title', 'Register Patient - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Register New Patient</h1>

    <p>
        Create a new patient record in the hospital management system.
    </p>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>Patient Information</h3>

        <a href="/patients">
            ← Back to Patients
        </a>

    </div>


    <form action="#" method="POST">

        <?php echo csrf_field(); ?>

        <!-- Personal Information -->

        <h3 style="
            color:#30245c;
            font-size:15px;
            margin-bottom:18px;
        ">
            Personal Information
        </h3>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        ">


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    First Name
                </label>

                <input
                    type="text"
                    placeholder="Enter first name"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Last Name
                </label>

                <input
                    type="text"
                    placeholder="Enter last name"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Date of Birth
                </label>

                <input
                    type="date"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Gender
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                    ">

                    <option>Select gender</option>
                    <option>Male</option>
                    <option>Female</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Phone Number
                </label>

                <input
                    type="text"
                    placeholder="Enter phone number"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Email Address
                </label>

                <input
                    type="email"
                    placeholder="patient@example.com"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>

        </div>


        <!-- Address -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Address Information
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">

                <div style="grid-column:1 / 3;">

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Residential Address
                    </label>

                    <input
                        type="text"
                        placeholder="Enter residential address"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        City
                    </label>

                    <input
                        type="text"
                        placeholder="Enter city"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        State
                    </label>

                    <input
                        type="text"
                        placeholder="Enter state"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>

            </div>

        </div>


        <!-- Medical Information -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Medical Information
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Blood Group
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                        ">

                        <option>Select blood group</option>
                        <option>A+</option>
                        <option>A-</option>
                        <option>B+</option>
                        <option>B-</option>
                        <option>AB+</option>
                        <option>AB-</option>
                        <option>O+</option>
                        <option>O-</option>

                    </select>

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Assigned Department
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                        ">

                        <option>Select department</option>
                        <option>Cardiology</option>
                        <option>Neurology</option>
                        <option>Pediatrics</option>
                        <option>Orthopedics</option>
                        <option>General Medicine</option>

                    </select>

                </div>


                <div style="grid-column:1 / 3;">

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Medical Notes
                    </label>

                    <textarea
                        rows="5"
                        placeholder="Enter allergies, previous conditions or other medical notes..."
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        resize:vertical;
                        "
                    ></textarea>

                </div>

            </div>

        </div>


        <!-- Emergency Contact -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Emergency Contact
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Contact Name
                    </label>

                    <input
                        type="text"
                        placeholder="Emergency contact name"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Contact Phone
                    </label>

                    <input
                        type="text"
                        placeholder="Emergency contact phone"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>

            </div>

        </div>


        <!-- Buttons -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
            display:flex;
            gap:10px;
        ">

            <button
                type="submit"
                style="
                background:#7357c7;
                color:white;
                border:none;
                padding:12px 24px;
                border-radius:9px;
                font-weight:bold;
                cursor:pointer;
                ">
                Register Patient
            </button>


            <a
                href="/patients"
                style="
                background:#f0ecfa;
                color:#6245b3;
                padding:12px 24px;
                border-radius:9px;
                text-decoration:none;
                font-weight:bold;
                ">
                Cancel
            </a>

        </div>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/patients/create.blade.php ENDPATH**/ ?>