

<?php $__env->startSection('title', 'Hospital Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Good Morning, Administrator 👋</h1>

    <p>
        Here is what's happening across MediCare Hospital today.
    </p>

</div>


<!-- STATISTICS -->

<div class="stats">

    <div class="stat">

        <div class="stat-icon">🧑‍🤝‍🧑</div>

        <h4>Total Patients</h4>

        <h2>1,248</h2>

        <span class="growth">+8.2%</span>

    </div>


    <div class="stat">

        <div class="stat-icon">👨‍⚕️</div>

        <h4>Medical Staff</h4>

        <h2>86</h2>

        <span class="growth">+3.4%</span>

    </div>


    <div class="stat">

        <div class="stat-icon">📅</div>

        <h4>Appointments</h4>

        <h2>154</h2>

        <span class="growth">Today</span>

    </div>


    <div class="stat">

        <div class="stat-icon">🛏️</div>

        <h4>Available Beds</h4>

        <h2>42</h2>

        <span class="growth">Ready</span>

    </div>

</div>


<!-- PATIENT VISITS CHART -->

<div class="chart-panel">

    <div class="chart-header">

        <h3>Patient Visits Overview</h3>

        <span>This Week</span>

    </div>


    <div class="chart">

        <div class="chart-bar" style="height: 55%;">
            <span>84</span>
        </div>

        <div class="chart-bar" style="height: 72%;">
            <span>112</span>
        </div>

        <div class="chart-bar" style="height: 63%;">
            <span>98</span>
        </div>

        <div class="chart-bar" style="height: 86%;">
            <span>136</span>
        </div>

        <div class="chart-bar" style="height: 78%;">
            <span>121</span>
        </div>

        <div class="chart-bar" style="height: 94%;">
            <span>148</span>
        </div>

        <div class="chart-bar" style="height: 67%;">
            <span>105</span>
        </div>

    </div>


    <div class="chart-labels">

        <span>Mon</span>
        <span>Tue</span>
        <span>Wed</span>
        <span>Thu</span>
        <span>Fri</span>
        <span>Sat</span>
        <span>Sun</span>

    </div>

</div>


<!-- MAIN DASHBOARD -->

<div class="dashboard-grid">


    <!-- APPOINTMENTS -->

    <div class="panel">

        <div class="panel-header">

            <h3>Today's Appointments</h3>

            <a href="/appointments">View All →</a>

        </div>


        <table>

            <thead>

                <tr>

                    <th>Patient</th>

                    <th>Doctor</th>

                    <th>Time</th>

                    <th>Status</th>

                </tr>

            </thead>


            <tbody>

                <tr>

                    <td class="patient">
                        John Williams
                    </td>

                    <td class="doctor">
                        Dr. Michael Brown
                    </td>

                    <td>
                        09:00 AM
                    </td>

                    <td>
                        <span class="badge confirmed">
                            Confirmed
                        </span>
                    </td>

                </tr>


                <tr>

                    <td class="patient">
                        Sarah Johnson
                    </td>

                    <td class="doctor">
                        Dr. Emily Davis
                    </td>

                    <td>
                        10:30 AM
                    </td>

                    <td>
                        <span class="badge waiting">
                            Waiting
                        </span>
                    </td>

                </tr>


                <tr>

                    <td class="patient">
                        David Anderson
                    </td>

                    <td class="doctor">
                        Dr. Robert Wilson
                    </td>

                    <td>
                        12:00 PM
                    </td>

                    <td>
                        <span class="badge confirmed">
                            Confirmed
                        </span>
                    </td>

                </tr>


                <tr>

                    <td class="patient">
                        Mary Thompson
                    </td>

                    <td class="doctor">
                        Dr. James Miller
                    </td>

                    <td>
                        02:30 PM
                    </td>

                    <td>
                        <span class="badge waiting">
                            Waiting
                        </span>
                    </td>

                </tr>

            </tbody>

        </table>

    </div>


    <!-- DEPARTMENTS -->

    <div class="panel">

        <div class="panel-header">

            <h3>Departments</h3>

            <a href="/departments">View All →</a>

        </div>


        <div class="department">

            <div class="department-info">

                <div class="department-icon">
                    ❤️
                </div>

                <div>
                    <strong>Cardiology</strong>
                    <small>12 Doctors</small>
                </div>

            </div>

        </div>


        <div class="department">

            <div class="department-info">

                <div class="department-icon">
                    🧠
                </div>

                <div>
                    <strong>Neurology</strong>
                    <small>8 Doctors</small>
                </div>

            </div>

        </div>


        <div class="department">

            <div class="department-info">

                <div class="department-icon">
                    👶
                </div>

                <div>
                    <strong>Pediatrics</strong>
                    <small>10 Doctors</small>
                </div>

            </div>

        </div>


        <div class="department">

            <div class="department-info">

                <div class="department-icon">
                    🦴
                </div>

                <div>
                    <strong>Orthopedics</strong>
                    <small>7 Doctors</small>
                </div>

            </div>

        </div>

    </div>

</div>


<!-- QUICK ACTIONS -->

<div class="panel">

    <div class="panel-header">

        <h3>Quick Actions</h3>

    </div>


    <div class="quick-actions">

        <a href="/patients" class="action">

            <div class="action-icon">
                ➕
            </div>

            <strong>Register Patient</strong>

            <small>
                Add a new patient record
            </small>

        </a>


        <a href="/appointments" class="action">

            <div class="action-icon">
                📅
            </div>

            <strong>Book Appointment</strong>

            <small>
                Schedule a patient visit
            </small>

        </a>


        <a href="/doctors" class="action">

            <div class="action-icon">
                👨‍⚕️
            </div>

            <strong>View Doctors</strong>

            <small>
                Manage medical staff
            </small>

        </a>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/dashboard/index.blade.php ENDPATH**/ ?>