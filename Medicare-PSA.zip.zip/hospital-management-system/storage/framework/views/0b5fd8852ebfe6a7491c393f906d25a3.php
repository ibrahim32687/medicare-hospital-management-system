

<?php $__env->startSection('title', 'Add Doctor - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Add New Doctor</h1>

    <p>
        Register a new medical professional into the hospital system.
    </p>

</div>


<div class="panel">

    <div class="panel-header">
        <h3>Doctor Information</h3>

        <a href="/doctors">
            ← Back to Doctors
        </a>
    </div>


    <form action="#" method="POST">

        <?php echo csrf_field(); ?>

        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        ">

            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    First Name
                </label>

                <input
                    type="text"
                    placeholder="Enter first name"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Last Name
                </label>

                <input
                    type="text"
                    placeholder="Enter last name"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Email Address
                </label>

                <input
                    type="email"
                    placeholder="doctor@example.com"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Phone Number
                </label>

                <input
                    type="text"
                    placeholder="Enter phone number"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Specialization
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                    ">

                    <option>Select specialization</option>
                    <option>Cardiology</option>
                    <option>Neurology</option>
                    <option>Pediatrics</option>
                    <option>Orthopedics</option>
                    <option>General Medicine</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Department
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                    ">

                    <option>Select department</option>
                    <option>Cardiology</option>
                    <option>Neurology</option>
                    <option>Pediatrics</option>
                    <option>Orthopedics</option>
                    <option>General Medicine</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Medical License Number
                </label>

                <input
                    type="text"
                    placeholder="Enter license number"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Years of Experience
                </label>

                <input
                    type="number"
                    placeholder="e.g. 5"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>

        </div>


        <div style="margin-top:22px;">

            <label style="
                display:block;
                margin-bottom:7px;
                color:#403464;
                font-size:13px;
                font-weight:bold;
            ">
                Professional Biography
            </label>

            <textarea
                rows="5"
                placeholder="Enter doctor's professional information..."
                style="
                width:100%;
                padding:12px;
                border:1px solid #e5dfef;
                border-radius:8px;
                outline:none;
                resize:vertical;
                "
            ></textarea>

        </div>


        <div style="
            margin-top:25px;
            display:flex;
            gap:10px;
        ">

            <button
                type="submit"
                style="
                background:#7357c7;
                color:white;
                border:none;
                padding:12px 22px;
                border-radius:9px;
                font-weight:bold;
                cursor:pointer;
                ">
                Save Doctor
            </button>


            <a
                href="/doctors"
                style="
                background:#f0ecfa;
                color:#6245b3;
                padding:12px 22px;
                border-radius:9px;
                text-decoration:none;
                font-weight:bold;
                ">
                Cancel
            </a>

        </div>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/doctors/create.blade.php ENDPATH**/ ?>