

<?php $__env->startSection('title', 'Department Details - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Department Details</h1>

    <p>
        View department information, staff and available resources.
    </p>

</div>


<!-- Department Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        flex-wrap:wrap;
        gap:20px;
    ">

        <div style="
            display:flex;
            align-items:center;
            gap:18px;
        ">

            <div style="
                width:70px;
                height:70px;
                border-radius:14px;
                background:#eee9fb;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:34px;
            ">
                ❤️
            </div>


            <div>

                <div style="
                    display:flex;
                    align-items:center;
                    gap:10px;
                    margin-bottom:6px;
                ">

                    <h2 style="
                        color:#30245c;
                        margin:0;
                    ">
                        Cardiology
                    </h2>

                    <span class="badge confirmed">
                        Active
                    </span>

                </div>


                <p style="
                    color:#827990;
                    font-size:12px;
                ">
                    Department Code: CARD-01
                </p>

            </div>

        </div>


        <a href="/departments"
           style="
           background:#f0ecfa;
           color:#6245b3;
           padding:11px 18px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           ">
            ← Back to Departments
        </a>

    </div>

</div>


<!-- Statistics -->

<div style="
    display:grid;
    grid-template-columns:repeat(4, 1fr);
    gap:18px;
    margin-bottom:22px;
">


    <div class="stat">

        <div class="stat-icon">👨‍⚕️</div>

        <h4>Doctors</h4>

        <h2>8</h2>

        <span class="growth">
            Medical Staff
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">👥</div>

        <h4>Patients</h4>

        <h2>146</h2>

        <span class="growth">
            This Month
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">🛏️</div>

        <h4>Total Beds</h4>

        <h2>24</h2>

        <span class="growth">
            Department
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">✓</div>

        <h4>Available Beds</h4>

        <h2>9</h2>

        <span class="growth">
            Available
        </span>

    </div>

</div>


<!-- Main Content -->

<div style="
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:22px;
">


    <!-- LEFT SIDE -->

    <div>


        <!-- About Department -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>About Cardiology</h3>

                <a href="#">
                    Edit Department
                </a>

            </div>


            <p style="
                color:#827990;
                font-size:13px;
                line-height:1.8;
            ">
                The Cardiology Department provides specialized
                diagnosis, treatment and preventive care for
                cardiovascular diseases. The department is
                equipped to handle routine consultations,
                cardiac assessments and specialized heart care.
            </p>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
                margin-top:22px;
                padding-top:20px;
                border-top:1px solid #eeeaf3;
            ">


                <div>

                    <small style="color:#8c8497;">
                        Department Head
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        Dr. Michael Brown
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Location
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        Block A, Floor 2
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Phone
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        +234 801 456 7821
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Email
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:6px;
                    ">
                        cardiology@medicare.com
                    </p>

                </div>

            </div>

        </div>


        <!-- Doctors -->

        <div class="panel">

            <div class="panel-header">

                <h3>Department Doctors</h3>

                <a href="/doctors">
                    View All →
                </a>

            </div>


            <table>

                <thead>

                    <tr>

                        <th>Doctor</th>

                        <th>Specialization</th>

                        <th>Experience</th>

                        <th>Status</th>

                    </tr>

                </thead>


                <tbody>


                    <tr>

                        <td class="doctor">
                            Dr. Michael Brown
                        </td>

                        <td>
                            Cardiology
                        </td>

                        <td>
                            12 Years
                        </td>

                        <td>

                            <span class="badge confirmed">
                                Available
                            </span>

                        </td>

                    </tr>


                    <tr>

                        <td class="doctor">
                            Dr. Sarah Adams
                        </td>

                        <td>
                            Interventional Cardiology
                        </td>

                        <td>
                            9 Years
                        </td>

                        <td>

                            <span class="badge confirmed">
                                Available
                            </span>

                        </td>

                    </tr>


                    <tr>

                        <td class="doctor">
                            Dr. James Miller
                        </td>

                        <td>
                            Cardiovascular Medicine
                        </td>

                        <td>
                            7 Years
                        </td>

                        <td>

                            <span class="badge waiting">
                                Busy
                            </span>

                        </td>

                    </tr>


                </tbody>

            </table>

        </div>

    </div>


    <!-- RIGHT SIDE -->

    <div>


        <!-- Bed Availability -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Bed Availability</h3>

            </div>


            <div style="
                text-align:center;
                padding:12px 0 18px;
            ">

                <div style="
                    width:120px;
                    height:120px;
                    border-radius:50%;
                    background:#f0ecfa;
                    margin:auto;
                    display:flex;
                    flex-direction:column;
                    align-items:center;
                    justify-content:center;
                ">

                    <strong style="
                        color:#7357c7;
                        font-size:30px;
                    ">
                        9
                    </strong>

                    <small style="color:#827990;">
                        Available
                    </small>

                </div>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Occupied
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    15
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Total Beds
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    24
                </strong>

            </div>

        </div>


        <!-- Quick Actions -->

        <div class="panel">

            <div class="panel-header">

                <h3>Quick Actions</h3>

            </div>


            <a href="/doctors"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                👨‍⚕️ View Doctors
            </a>


            <a href="/patients"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                👥 View Patients
            </a>


            <a href="/appointments"
               style="
               display:block;
               padding:13px;
               background:#f5f1fc;
               color:#6245b3;
               text-decoration:none;
               border-radius:8px;
               margin-bottom:10px;
               font-size:13px;
               font-weight:bold;
               ">
                📅 View Appointments
            </a>


            <a href="/departments"
               style="
               display:block;
               padding:13px;
               background:#7357c7;
               color:white;
               text-decoration:none;
               border-radius:8px;
               font-size:13px;
               font-weight:bold;
               text-align:center;
               ">
                ← All Departments
            </a>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/departments/show.blade.php ENDPATH**/ ?>