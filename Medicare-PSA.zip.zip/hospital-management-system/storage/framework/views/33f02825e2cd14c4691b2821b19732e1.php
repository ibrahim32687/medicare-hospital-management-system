

<?php $__env->startSection('title', 'Invoice Details - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Invoice Details</h1>

    <p>
        Review invoice information, services, payment status and billing history.
    </p>

</div>


<!-- Invoice Header -->

<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        flex-wrap:wrap;
        gap:20px;
    ">

        <div>

            <div style="
                display:flex;
                align-items:center;
                gap:10px;
                margin-bottom:7px;
            ">

                <h2 style="
                    color:#30245c;
                    margin:0;
                ">
                    Invoice INV-3048
                </h2>

                <span class="badge confirmed">
                    Paid
                </span>

            </div>

            <p style="
                color:#827990;
                font-size:12px;
            ">
                Issued on 24 August 2026
            </p>

        </div>


        <div style="
            display:flex;
            gap:10px;
        ">

            <a href="#"
               style="
               background:#f0ecfa;
               color:#6245b3;
               padding:11px 18px;
               border-radius:9px;
               text-decoration:none;
               font-size:13px;
               font-weight:bold;
               ">
                🖨️ Print Invoice
            </a>


            <a href="/billing"
               style="
               background:#7357c7;
               color:white;
               padding:11px 18px;
               border-radius:9px;
               text-decoration:none;
               font-size:13px;
               font-weight:bold;
               ">
                ← All Invoices
            </a>

        </div>

    </div>

</div>


<!-- Main Layout -->

<div style="
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:22px;
">


    <!-- LEFT SIDE -->

    <div>


        <!-- Patient Information -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Patient Information</h3>

                <a href="/patients/1">
                    View Patient →
                </a>

            </div>


            <div style="
                display:flex;
                align-items:center;
                gap:18px;
            ">

                <div style="
                    width:65px;
                    height:65px;
                    border-radius:50%;
                    background:#eee9fb;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:29px;
                ">
                    👤
                </div>


                <div>

                    <h3 style="
                        color:#403464;
                        margin-bottom:5px;
                    ">
                        John Williams
                    </h3>

                    <p style="
                        color:#827990;
                        font-size:12px;
                    ">
                        Patient ID: PT-1001
                    </p>

                </div>

            </div>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr 1fr;
                gap:18px;
                margin-top:20px;
                padding-top:18px;
                border-top:1px solid #eeeaf3;
            ">


                <div>

                    <small style="color:#8c8497;">
                        Phone
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        +234 801 234 5678
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Invoice Date
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        24 Aug 2026
                    </p>

                </div>


                <div>

                    <small style="color:#8c8497;">
                        Due Date
                    </small>

                    <p style="
                        color:#403464;
                        font-weight:bold;
                        margin-top:5px;
                    ">
                        31 Aug 2026
                    </p>

                </div>

            </div>

        </div>


        <!-- Invoice Items -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Invoice Items</h3>

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    3 Services
                </span>

            </div>


            <table>

                <thead>

                    <tr>

                        <th>Service</th>

                        <th>Quantity</th>

                        <th>Unit Price</th>

                        <th>Total</th>

                    </tr>

                </thead>


                <tbody>


                    <tr>

                        <td class="doctor">
                            Medical Consultation
                        </td>

                        <td>
                            1
                        </td>

                        <td>
                            ₦45,000
                        </td>

                        <td>
                            ₦45,000
                        </td>

                    </tr>


                    <tr>

                        <td class="doctor">
                            Blood Pressure Test
                        </td>

                        <td>
                            1
                        </td>

                        <td>
                            ₦5,000
                        </td>

                        <td>
                            ₦5,000
                        </td>

                    </tr>


                    <tr>

                        <td class="doctor">
                            Laboratory Investigation
                        </td>

                        <td>
                            1
                        </td>

                        <td>
                            ₦15,000
                        </td>

                        <td>
                            ₦15,000
                        </td>

                    </tr>


                </tbody>

            </table>


            <!-- Totals -->

            <div style="
                max-width:350px;
                margin-left:auto;
                margin-top:20px;
            ">


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:9px 0;
                    color:#827990;
                    font-size:13px;
                ">

                    <span>
                        Subtotal
                    </span>

                    <strong style="color:#403464;">
                        ₦65,000
                    </strong>

                </div>


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:9px 0;
                    color:#827990;
                    font-size:13px;
                ">

                    <span>
                        Discount
                    </span>

                    <strong style="color:#403464;">
                        ₦0
                    </strong>

                </div>


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:9px 0;
                    color:#827990;
                    font-size:13px;
                    border-bottom:1px solid #eeeaf3;
                ">

                    <span>
                        Tax
                    </span>

                    <strong style="color:#403464;">
                        ₦0
                    </strong>

                </div>


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding-top:15px;
                ">

                    <strong style="
                        color:#30245c;
                        font-size:16px;
                    ">
                        Total Amount
                    </strong>

                    <strong style="
                        color:#7357c7;
                        font-size:20px;
                    ">
                        ₦65,000
                    </strong>

                </div>

            </div>

        </div>


        <!-- Payment History -->

        <div class="panel">

            <div class="panel-header">

                <h3>Payment History</h3>

            </div>


            <table>

                <thead>

                    <tr>

                        <th>Date</th>

                        <th>Payment Method</th>

                        <th>Reference</th>

                        <th>Amount</th>

                        <th>Status</th>

                    </tr>

                </thead>


                <tbody>

                    <tr>

                        <td>
                            24 Aug 2026
                        </td>

                        <td>
                            Bank Transfer
                        </td>

                        <td>
                            TRX-82941
                        </td>

                        <td>
                            ₦65,000
                        </td>

                        <td>

                            <span class="badge confirmed">
                                Successful
                            </span>

                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>


    <!-- RIGHT SIDE -->

    <div>


        <!-- Payment Status -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Payment Status</h3>

            </div>


            <div style="
                text-align:center;
                padding:15px 0 20px;
            ">

                <div style="
                    width:105px;
                    height:105px;
                    border-radius:50%;
                    background:#eee9fb;
                    margin:auto;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:38px;
                ">
                    ✓
                </div>


                <h2 style="
                    color:#7357c7;
                    margin-top:15px;
                ">
                    PAID
                </h2>


                <p style="
                    color:#827990;
                    font-size:12px;
                ">
                    Payment received successfully
                </p>

            </div>


            <div style="
                padding-top:15px;
                border-top:1px solid #eeeaf3;
                display:flex;
                justify-content:space-between;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Amount Paid
                </span>

                <strong style="
                    color:#403464;
                    font-size:13px;
                ">
                    ₦65,000
                </strong>

            </div>

        </div>


        <!-- Invoice Summary -->

        <div class="panel" style="margin-bottom:22px;">

            <div class="panel-header">

                <h3>Invoice Summary</h3>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Invoice Number
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    INV-3048
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Invoice Date
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    24 Aug 2026
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
                border-bottom:1px solid #eeeaf3;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Due Date
                </span>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    31 Aug 2026
                </strong>

            </div>


            <div style="
                display:flex;
                justify-content:space-between;
                padding:12px 0;
            ">

                <span style="
                    color:#827990;
                    font-size:12px;
                ">
                    Balance
                </span>

                <strong style="
                    color:#7357c7;
                    font-size:13px;
                ">
                    ₦0
                </strong>

            </div>

        </div>


        <!-- Billing Contact -->

        <div class="panel">

            <div class="panel-header">

                <h3>Billing Department</h3>

            </div>


            <p style="
                color:#403464;
                font-weight:bold;
                font-size:13px;
                margin-bottom:8px;
            ">
                MediCare Hospital
            </p>


            <p style="
                color:#827990;
                font-size:12px;
                line-height:1.8;
            ">
                For questions about this invoice or
                payment, please contact the hospital
                billing department.
            </p>


            <div style="
                margin-top:15px;
                padding-top:15px;
                border-top:1px solid #eeeaf3;
            ">

                <p style="
                    color:#6245b3;
                    font-size:12px;
                    font-weight:bold;
                ">
                    billing@medicare.com
                </p>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/billing/show.blade.php ENDPATH**/ ?>