<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'MediCare Hospital'); ?></title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            background: #f5f3fa;
            color: #30245c;
        }

        /* ================================
           TOP NAVIGATION
        ================================= */

        .navbar {
            height: 74px;
            background: #ffffff;
            border-bottom: 1px solid #e6e0f1;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 35px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-icon {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, #7357c7, #49377d);
            color: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            box-shadow: 0 5px 12px rgba(115, 87, 199, 0.25);
        }

        .brand h2 {
            font-size: 20px;
            color: #30245c;
        }

        .brand small {
            display: block;
            color: #8d849f;
            font-size: 11px;
            margin-top: 2px;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 22px;
        }

        .search {
            background: #f7f5fb;
            border: 1px solid #e5dfef;
            border-radius: 10px;
            padding: 11px 15px;
            width: 250px;
            outline: none;
            color: #30245c;
        }

        .search:focus {
            border-color: #7357c7;
        }

        .notification {
            width: 38px;
            height: 38px;
            background: #f1edfa;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile strong {
            display: block;
            font-size: 13px;
            color: #30245c;
        }

        .profile small {
            display: block;
            color: #91889f;
            font-size: 11px;
            margin-top: 3px;
        }

        .profile-avatar {
            width: 40px;
            height: 40px;
            background: #eee9fb;
            color: #6245b3;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }


        /* ================================
           MAIN NAVIGATION
        ================================= */

        .menu {
            background: #30245c;
            padding: 0 35px;
            display: flex;
            align-items: center;
            gap: 4px;
            min-height: 54px;
            box-shadow: 0 3px 10px rgba(48, 36, 92, 0.12);
        }

        .menu a {
            text-decoration: none;
            color: #ddd7ed;
            padding: 18px 15px;
            font-size: 13px;
            transition: 0.3s;
            border-bottom: 3px solid transparent;
        }

        .menu a:hover {
            background: #49377d;
            color: white;
            border-bottom-color: #a995e8;
        }


        /* ================================
           MAIN CONTENT
        ================================= */

        .container {
            max-width: 1450px;
            margin: auto;
            padding: 32px 35px 55px;
        }

        .page-heading {
            margin-bottom: 28px;
        }

        .page-heading h1 {
            font-size: 28px;
            color: #30245c;
            margin-bottom: 7px;
        }

        .page-heading p {
            color: #827990;
            font-size: 14px;
        }


        /* ================================
           STATISTICS
        ================================= */

        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat {
            background: white;
            border: 1px solid #e8e2f1;
            border-radius: 14px;
            padding: 22px;
            position: relative;
            transition: 0.3s;
        }

        .stat:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(48, 36, 92, 0.08);
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 11px;
            background: #f0ecfa;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
            margin-bottom: 16px;
        }

        .stat h4 {
            color: #8a8198;
            font-size: 11px;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat h2 {
            font-size: 28px;
            color: #30245c;
        }

        .growth {
            position: absolute;
            right: 18px;
            bottom: 22px;
            color: #7357c7;
            font-size: 11px;
            font-weight: bold;
            background: #f0ecfa;
            padding: 5px 8px;
            border-radius: 15px;
        }


        /* ================================
           DASHBOARD GRID
        ================================= */

        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 22px;
            margin-bottom: 22px;
        }

        .panel {
            background: white;
            border: 1px solid #e8e2f1;
            border-radius: 14px;
            padding: 24px;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .panel-header h3 {
            color: #30245c;
            font-size: 17px;
        }

        .panel-header a {
            color: #7357c7;
            text-decoration: none;
            font-size: 12px;
            font-weight: bold;
        }


        /* ================================
           CHART
        ================================= */

        .chart-panel {
            background: white;
            border: 1px solid #e8e2f1;
            border-radius: 14px;
            padding: 24px;
            margin-bottom: 22px;
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-header h3 {
            color: #30245c;
            font-size: 17px;
        }

        .chart-header span {
            background: #f0ecfa;
            color: #7357c7;
            padding: 7px 12px;
            border-radius: 20px;
            font-size: 11px;
        }

        .chart {
            height: 230px;
            display: flex;
            align-items: flex-end;
            justify-content: space-around;
            gap: 20px;
            padding: 15px 10px 0;
            border-bottom: 1px solid #e8e2f1;
            position: relative;
        }

        .chart::before {
            content: "";
            position: absolute;
            left: 0;
            right: 0;
            top: 50%;
            border-top: 1px dashed #e4deed;
        }

        .chart-bar {
            width: 9%;
            max-width: 55px;
            background: linear-gradient(to top, #7357c7, #a995e8);
            border-radius: 9px 9px 0 0;
            position: relative;
            z-index: 2;
            transition: 0.3s;
        }

        .chart-bar:hover {
            background: linear-gradient(to top, #6245b3, #8d76d5);
            transform: translateY(-4px);
        }

        .chart-bar span {
            position: absolute;
            top: -22px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 10px;
            color: #6f6680;
            font-weight: bold;
        }

        .chart-labels {
            display: flex;
            justify-content: space-around;
            padding-top: 10px;
        }

        .chart-labels span {
            font-size: 11px;
            color: #8c8497;
            width: 12%;
            text-align: center;
        }


        /* ================================
           TABLE
        ================================= */

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            font-size: 11px;
            color: #8b8298;
            text-transform: uppercase;
            padding: 12px 8px;
            border-bottom: 1px solid #eeeaf3;
        }

        td {
            padding: 15px 8px;
            font-size: 13px;
            border-bottom: 1px solid #f1eef5;
        }

        .patient {
            font-weight: bold;
            color: #403464;
        }

        .doctor {
            color: #827990;
        }

        .badge {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
        }

        .confirmed {
            background: #e7f7ee;
            color: #25845a;
        }

        .waiting {
            background: #fff1dc;
            color: #a96a16;
        }


        /* ================================
           DEPARTMENTS
        ================================= */

        .department {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 13px 0;
            border-bottom: 1px solid #eeeaf3;
        }

        .department-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .department-icon {
            width: 39px;
            height: 39px;
            border-radius: 10px;
            background: #f0ecfa;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .department strong {
            font-size: 13px;
            color: #403464;
        }

        .department small {
            display: block;
            color: #8c8497;
            margin-top: 3px;
            font-size: 11px;
        }


        /* ================================
           QUICK ACTIONS
        ================================= */

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .action {
            border: 1px solid #e5dfef;
            background: #ffffff;
            border-radius: 11px;
            padding: 18px;
            text-decoration: none;
            color: #30245c;
            transition: 0.3s;
        }

        .action:hover {
            border-color: #7357c7;
            background: #faf8fe;
            transform: translateY(-3px);
        }

        .action-icon {
            width: 40px;
            height: 40px;
            background: #f0ecfa;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .action strong {
            font-size: 13px;
        }

        .action small {
            display: block;
            color: #8c8497;
            margin-top: 5px;
            font-size: 11px;
        }


        /* ================================
           RESPONSIVE
        ================================= */

        @media (max-width: 1050px) {

            .stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 750px) {

            .navbar {
                padding: 0 15px;
            }

            .search {
                display: none;
            }

            .menu {
                padding: 0 10px;
                overflow-x: auto;
            }

            .container {
                padding: 25px 15px;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }

            .profile > div:first-child {
                display: none;
            }
        }
    </style>
</head>

<body>

    <!-- TOP HEADER -->

    <header class="navbar">

        <div class="brand">

            <div class="brand-icon">
                🏥
            </div>

            <div>
                <h2>MediCare</h2>
                <small>Hospital Management System</small>
            </div>

        </div>


        <div class="nav-right">

            <input
                type="text"
                class="search"
                placeholder="Search hospital records..."
            >

            <div class="notification">
                🔔
            </div>

            <div class="profile">

                <div>
                    <strong>Administrator</strong>
                    <small>Hospital Admin</small>
                </div>

                <div class="profile-avatar">
                    AD
                </div>

            </div>

        </div>

    </header>


    <!-- NAVIGATION -->

    <nav class="menu">

        <a href="/dashboard">Overview</a>

        <a href="/patients">Patients</a>

        <a href="/doctors">Doctors</a>

        <a href="/appointments">Appointments</a>

        <a href="/departments">Departments</a>

        <a href="/medical-records">Medical Records</a>

        <a href="/billing">Billing</a>

    </nav>


    <!-- CONTENT -->

    <main class="container">

        <?php echo $__env->yieldContent('content'); ?>

    </main>

</body>
</html><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/layout.blade.php ENDPATH**/ ?>