

<?php $__env->startSection('title', 'Create Invoice - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Create New Invoice</h1>

    <p>
        Generate a patient invoice for medical services and treatments.
    </p>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>Invoice Information</h3>

        <a href="/billing">
            ← Back to Billing
        </a>

    </div>


    <form action="#" method="POST">

        <?php echo csrf_field(); ?>


        <!-- Patient Information -->

        <h3 style="
            color:#30245c;
            font-size:15px;
            margin-bottom:18px;
        ">
            Patient Information
        </h3>


        <div style="
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        ">


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Patient
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Select patient</option>
                    <option>PT-1001 - John Williams</option>
                    <option>PT-1002 - Sarah Johnson</option>
                    <option>PT-1003 - David Anderson</option>
                    <option>PT-1004 - Mary Thompson</option>
                    <option>PT-1005 - James Wilson</option>

                </select>

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Invoice Date
                </label>

                <input
                    type="date"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Due Date
                </label>

                <input
                    type="date"
                    style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    "
                >

            </div>


            <div>

                <label style="
                    display:block;
                    margin-bottom:7px;
                    color:#403464;
                    font-size:13px;
                    font-weight:bold;
                ">
                    Payment Status
                </label>

                <select style="
                    width:100%;
                    padding:12px;
                    border:1px solid #e5dfef;
                    border-radius:8px;
                    outline:none;
                    background:white;
                ">

                    <option>Pending</option>
                    <option>Paid</option>
                    <option>Partially Paid</option>
                    <option>Overdue</option>

                </select>

            </div>

        </div>


        <!-- Services -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Medical Services
            </h3>


            <div style="
                display:grid;
                grid-template-columns:2fr 1fr 1fr;
                gap:15px;
                margin-bottom:12px;
            ">

                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Service
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                    ">

                        <option>Select service</option>
                        <option>Medical Consultation</option>
                        <option>Laboratory Test</option>
                        <option>Pharmacy</option>
                        <option>Hospital Admission</option>
                        <option>Diagnostic Imaging</option>

                    </select>

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Quantity
                    </label>

                    <input
                        type="number"
                        value="1"
                        min="1"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Amount (₦)
                    </label>

                    <input
                        type="number"
                        placeholder="0.00"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>

            </div>


            <button
                type="button"
                style="
                background:#f0ecfa;
                color:#6245b3;
                border:none;
                padding:10px 16px;
                border-radius:8px;
                font-weight:bold;
                cursor:pointer;
                ">
                + Add Another Service
            </button>

        </div>


        <!-- Payment Summary -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Payment Summary
            </h3>


            <div style="
                max-width:420px;
                margin-left:auto;
                background:#faf9fc;
                padding:20px;
                border-radius:10px;
            ">


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:10px 0;
                    color:#827990;
                    font-size:13px;
                ">

                    <span>
                        Subtotal
                    </span>

                    <strong style="color:#403464;">
                        ₦0.00
                    </strong>

                </div>


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:10px 0;
                    color:#827990;
                    font-size:13px;
                ">

                    <span>
                        Discount
                    </span>

                    <strong style="color:#403464;">
                        ₦0.00
                    </strong>

                </div>


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding:10px 0;
                    color:#827990;
                    font-size:13px;
                    border-bottom:1px solid #e5dfef;
                ">

                    <span>
                        Tax
                    </span>

                    <strong style="color:#403464;">
                        ₦0.00
                    </strong>

                </div>


                <div style="
                    display:flex;
                    justify-content:space-between;
                    padding-top:15px;
                ">

                    <strong style="
                        color:#30245c;
                        font-size:16px;
                    ">
                        Total
                    </strong>

                    <strong style="
                        color:#7357c7;
                        font-size:20px;
                    ">
                        ₦0.00
                    </strong>

                </div>

            </div>

        </div>


        <!-- Payment Method -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
        ">

            <h3 style="
                color:#30245c;
                font-size:15px;
                margin-bottom:18px;
            ">
                Payment Method
            </h3>


            <div style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:20px;
            ">


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Payment Method
                    </label>

                    <select style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        background:white;
                    ">

                        <option>Select payment method</option>
                        <option>Cash</option>
                        <option>Bank Transfer</option>
                        <option>POS</option>
                        <option>Card</option>
                        <option>Insurance</option>

                    </select>

                </div>


                <div>

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Reference Number
                    </label>

                    <input
                        type="text"
                        placeholder="Payment reference"
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        "
                    >

                </div>


                <div style="grid-column:1 / 3;">

                    <label style="
                        display:block;
                        margin-bottom:7px;
                        color:#403464;
                        font-size:13px;
                        font-weight:bold;
                    ">
                        Notes
                    </label>

                    <textarea
                        rows="4"
                        placeholder="Additional billing notes..."
                        style="
                        width:100%;
                        padding:12px;
                        border:1px solid #e5dfef;
                        border-radius:8px;
                        outline:none;
                        resize:vertical;
                        "
                    ></textarea>

                </div>

            </div>

        </div>


        <!-- Buttons -->

        <div style="
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #eeeaf3;
            display:flex;
            gap:10px;
        ">

            <button
                type="submit"
                style="
                background:#7357c7;
                color:white;
                border:none;
                padding:12px 24px;
                border-radius:9px;
                font-weight:bold;
                cursor:pointer;
                ">
                Create Invoice
            </button>


            <a
                href="/billing"
                style="
                background:#f0ecfa;
                color:#6245b3;
                padding:12px 24px;
                border-radius:9px;
                text-decoration:none;
                font-weight:bold;
                ">
                Cancel
            </a>

        </div>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/billing/create.blade.php ENDPATH**/ ?>