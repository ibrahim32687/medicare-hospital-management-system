

<?php $__env->startSection('title', 'Patients - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Patient Directory</h1>

    <p>
        Search, manage and monitor registered patients.
    </p>

</div>


<div class="panel" style="margin-bottom:22px;">

    <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:20px;
    ">

        <div style="flex:1;">

            <input
                type="text"
                placeholder="🔍 Search patients by name, ID or phone..."
                style="
                width:100%;
                padding:13px 16px;
                border:1px solid #e5dfef;
                border-radius:9px;
                outline:none;
                background:#faf9fc;
                "
            >

        </div>


        <a href="/patients/create"
           style="
           background:#7357c7;
           color:white;
           padding:12px 20px;
           border-radius:9px;
           text-decoration:none;
           font-size:13px;
           font-weight:bold;
           white-space:nowrap;
           ">
            + Register Patient
        </a>

    </div>

</div>


<div style="
    display:grid;
    grid-template-columns:repeat(3, 1fr);
    gap:18px;
    margin-bottom:22px;
">


    <div class="stat">

        <div class="stat-icon">👥</div>

        <h4>Registered Patients</h4>

        <h2>1,248</h2>

        <span class="growth">+8.2%</span>

    </div>


    <div class="stat">

        <div class="stat-icon">🆕</div>

        <h4>New This Month</h4>

        <h2>126</h2>

        <span class="growth">+12%</span>

    </div>


    <div class="stat">

        <div class="stat-icon">🏥</div>

        <h4>Currently Admitted</h4>

        <h2>74</h2>

        <span class="growth">Active</span>

    </div>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>Recent Patients</h3>

        <a href="/patients/create">
            Register New →
        </a>

    </div>


    <table>

        <thead>

            <tr>

                <th>Patient ID</th>

                <th>Patient</th>

                <th>Age</th>

                <th>Gender</th>

                <th>Department</th>

                <th>Status</th>

                <th>Action</th>

            </tr>

        </thead>


        <tbody>


            <tr>

                <td>
                    <strong style="color:#7357c7;">
                        PT-1001
                    </strong>
                </td>

                <td class="patient">
                    John Williams
                </td>

                <td>42</td>

                <td>Male</td>

                <td>Cardiology</td>

                <td>
                    <span class="badge confirmed">
                        Active
                    </span>
                </td>

                <td>
                    <a href="/patients/1"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-size:12px;
                       font-weight:bold;
                       ">
                        View →
                    </a>
                </td>

            </tr>


            <tr>

                <td>
                    <strong style="color:#7357c7;">
                        PT-1002
                    </strong>
                </td>

                <td class="patient">
                    Sarah Johnson
                </td>

                <td>29</td>

                <td>Female</td>

                <td>Pediatrics</td>

                <td>
                    <span class="badge confirmed">
                        Active
                    </span>
                </td>

                <td>
                    <a href="/patients/2"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-size:12px;
                       font-weight:bold;
                       ">
                        View →
                    </a>
                </td>

            </tr>


            <tr>

                <td>
                    <strong style="color:#7357c7;">
                        PT-1003
                    </strong>
                </td>

                <td class="patient">
                    David Anderson
                </td>

                <td>56</td>

                <td>Male</td>

                <td>Neurology</td>

                <td>
                    <span class="badge waiting">
                        Admitted
                    </span>
                </td>

                <td>
                    <a href="/patients/3"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-size:12px;
                       font-weight:bold;
                       ">
                        View →
                    </a>
                </td>

            </tr>


            <tr>

                <td>
                    <strong style="color:#7357c7;">
                        PT-1004
                    </strong>
                </td>

                <td class="patient">
                    Mary Thompson
                </td>

                <td>35</td>

                <td>Female</td>

                <td>Orthopedics</td>

                <td>
                    <span class="badge confirmed">
                        Active
                    </span>
                </td>

                <td>
                    <a href="/patients/4"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-size:12px;
                       font-weight:bold;
                       ">
                        View →
                    </a>
                </td>

            </tr>


            <tr>

                <td>
                    <strong style="color:#7357c7;">
                        PT-1005
                    </strong>
                </td>

                <td class="patient">
                    James Wilson
                </td>

                <td>63</td>

                <td>Male</td>

                <td>General Medicine</td>

                <td>
                    <span class="badge confirmed">
                        Active
                    </span>
                </td>

                <td>
                    <a href="/patients/5"
                       style="
                       color:#7357c7;
                       text-decoration:none;
                       font-size:12px;
                       font-weight:bold;
                       ">
                        View →
                    </a>
                </td>

            </tr>


        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/patients/index.blade.php ENDPATH**/ ?>