

<?php $__env->startSection('title', 'Appointments - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Appointment Schedule</h1>

    <p>
        Manage upcoming consultations, appointments and schedules.
    </p>

</div>


<!-- Top Controls -->

<div style="
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:22px;
">

    <div>

        <button style="
            background:#7357c7;
            color:white;
            border:none;
            padding:11px 18px;
            border-radius:9px;
            font-weight:bold;
        ">
            Today
        </button>

        <button style="
            background:#f0ecfa;
            color:#6245b3;
            border:none;
            padding:11px 18px;
            border-radius:9px;
            margin-left:7px;
        ">
            This Week
        </button>

    </div>


    <a href="/appointments/create"
       style="
       background:#7357c7;
       color:white;
       padding:12px 20px;
       border-radius:9px;
       text-decoration:none;
       font-size:13px;
       font-weight:bold;
       ">
        + New Appointment
    </a>

</div>


<!-- Appointment Summary -->

<div style="
    display:grid;
    grid-template-columns:repeat(4, 1fr);
    gap:18px;
    margin-bottom:22px;
">


    <div class="stat">

        <div class="stat-icon">📅</div>

        <h4>Today's Appointments</h4>

        <h2>24</h2>

        <span class="growth">
            Scheduled
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">⏳</div>

        <h4>Waiting</h4>

        <h2>7</h2>

        <span class="growth">
            Patients
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">✓</div>

        <h4>Completed</h4>

        <h2>13</h2>

        <span class="growth">
            Today
        </span>

    </div>


    <div class="stat">

        <div class="stat-icon">✕</div>

        <h4>Cancelled</h4>

        <h2>2</h2>

        <span class="growth">
            Today
        </span>

    </div>

</div>


<!-- Schedule -->

<div class="panel">

    <div class="panel-header">

        <h3>Today's Schedule</h3>

        <span style="
            color:#827990;
            font-size:12px;
        ">
            Monday, 24 August 2026
        </span>

    </div>


    <div style="
        display:flex;
        flex-direction:column;
    ">


        <!-- Appointment 1 -->

        <div style="
            display:grid;
            grid-template-columns:100px 1fr 180px 120px;
            align-items:center;
            gap:20px;
            padding:20px 5px;
            border-bottom:1px solid #eeeaf3;
        ">

            <div>

                <strong style="
                    color:#7357c7;
                    font-size:15px;
                ">
                    09:00 AM
                </strong>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:14px;
                ">
                    John Williams
                </strong>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:5px;
                ">
                    General Consultation
                </p>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    Dr. Michael Brown
                </strong>

                <p style="
                    color:#827990;
                    font-size:11px;
                    margin-top:4px;
                ">
                    Cardiology
                </p>

            </div>


            <div>

                <span class="badge confirmed">
                    Confirmed
                </span>

            </div>

        </div>


        <!-- Appointment 2 -->

        <div style="
            display:grid;
            grid-template-columns:100px 1fr 180px 120px;
            align-items:center;
            gap:20px;
            padding:20px 5px;
            border-bottom:1px solid #eeeaf3;
        ">

            <div>

                <strong style="
                    color:#7357c7;
                    font-size:15px;
                ">
                    10:30 AM
                </strong>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:14px;
                ">
                    Sarah Johnson
                </strong>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:5px;
                ">
                    Pediatric Consultation
                </p>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    Dr. Emily Davis
                </strong>

                <p style="
                    color:#827990;
                    font-size:11px;
                    margin-top:4px;
                ">
                    Pediatrics
                </p>

            </div>


            <div>

                <span class="badge waiting">
                    Waiting
                </span>

            </div>

        </div>


        <!-- Appointment 3 -->

        <div style="
            display:grid;
            grid-template-columns:100px 1fr 180px 120px;
            align-items:center;
            gap:20px;
            padding:20px 5px;
            border-bottom:1px solid #eeeaf3;
        ">

            <div>

                <strong style="
                    color:#7357c7;
                    font-size:15px;
                ">
                    12:00 PM
                </strong>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:14px;
                ">
                    David Anderson
                </strong>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:5px;
                ">
                    Neurology Follow-up
                </p>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    Dr. Robert Wilson
                </strong>

                <p style="
                    color:#827990;
                    font-size:11px;
                    margin-top:4px;
                ">
                    Neurology
                </p>

            </div>


            <div>

                <span class="badge confirmed">
                    Confirmed
                </span>

            </div>

        </div>


        <!-- Appointment 4 -->

        <div style="
            display:grid;
            grid-template-columns:100px 1fr 180px 120px;
            align-items:center;
            gap:20px;
            padding:20px 5px;
        ">

            <div>

                <strong style="
                    color:#7357c7;
                    font-size:15px;
                ">
                    02:30 PM
                </strong>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:14px;
                ">
                    Mary Thompson
                </strong>

                <p style="
                    color:#827990;
                    font-size:12px;
                    margin-top:5px;
                ">
                    Orthopedic Review
                </p>

            </div>


            <div>

                <strong style="
                    color:#403464;
                    font-size:12px;
                ">
                    Dr. Michael Brown
                </strong>

                <p style="
                    color:#827990;
                    font-size:11px;
                    margin-top:4px;
                ">
                    Orthopedics
                </p>

            </div>


            <div>

                <span class="badge confirmed">
                    Confirmed
                </span>

            </div>

        </div>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/appointments/index.blade.php ENDPATH**/ ?>