

<?php $__env->startSection('title', 'Doctors - MediCare Hospital'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">

    <h1>Medical Doctors</h1>

    <p>
        Manage doctors and medical staff working across MediCare Hospital.
    </p>

</div>


<div style="
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:22px;
">

    <div style="color:#827990; font-size:13px;">
        86 doctors registered
    </div>

    <a href="/doctors/create"
       style="
       background:#7357c7;
       color:white;
       padding:11px 18px;
       border-radius:9px;
       text-decoration:none;
       font-size:13px;
       font-weight:bold;
       ">
        + Add New Doctor
    </a>

</div>


<div style="
    display:grid;
    grid-template-columns:repeat(3, 1fr);
    gap:20px;
">


    <!-- Doctor 1 -->

    <div class="panel">

        <div style="
            display:flex;
            align-items:center;
            gap:15px;
            margin-bottom:18px;
        ">

            <div style="
                width:55px;
                height:55px;
                background:#eee9fb;
                border-radius:50%;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:25px;
            ">
                👨‍⚕️
            </div>

            <div>

                <h3 style="
                    color:#30245c;
                    font-size:16px;
                    margin-bottom:5px;
                ">
                    Dr. Michael Brown
                </h3>

                <small style="color:#8c8497;">
                    Cardiologist
                </small>

            </div>

        </div>


        <p style="
            color:#827990;
            font-size:13px;
            margin-bottom:15px;
        ">
            Specializes in cardiovascular diseases and
            heart-related treatments.
        </p>


        <div style="
            border-top:1px solid #eeeaf3;
            padding-top:14px;
            margin-bottom:15px;
        ">

            <strong style="
                color:#403464;
                font-size:12px;
            ">
                Department
            </strong>

            <p style="
                color:#827990;
                font-size:12px;
                margin-top:4px;
            ">
                Cardiology
            </p>

        </div>


        <a href="/doctors/1"
           style="
           color:#7357c7;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Profile →
        </a>

    </div>


    <!-- Doctor 2 -->

    <div class="panel">

        <div style="
            display:flex;
            align-items:center;
            gap:15px;
            margin-bottom:18px;
        ">

            <div style="
                width:55px;
                height:55px;
                background:#eee9fb;
                border-radius:50%;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:25px;
            ">
                👩‍⚕️
            </div>

            <div>

                <h3 style="
                    color:#30245c;
                    font-size:16px;
                    margin-bottom:5px;
                ">
                    Dr. Emily Davis
                </h3>

                <small style="color:#8c8497;">
                    Pediatrician
                </small>

            </div>

        </div>


        <p style="
            color:#827990;
            font-size:13px;
            margin-bottom:15px;
        ">
            Provides specialized medical care and treatment
            for children and young patients.
        </p>


        <div style="
            border-top:1px solid #eeeaf3;
            padding-top:14px;
            margin-bottom:15px;
        ">

            <strong style="
                color:#403464;
                font-size:12px;
            ">
                Department
            </strong>

            <p style="
                color:#827990;
                font-size:12px;
                margin-top:4px;
            ">
                Pediatrics
            </p>

        </div>


        <a href="/doctors/2"
           style="
           color:#7357c7;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Profile →
        </a>

    </div>


    <!-- Doctor 3 -->

    <div class="panel">

        <div style="
            display:flex;
            align-items:center;
            gap:15px;
            margin-bottom:18px;
        ">

            <div style="
                width:55px;
                height:55px;
                background:#eee9fb;
                border-radius:50%;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:25px;
            ">
                👨‍⚕️
            </div>

            <div>

                <h3 style="
                    color:#30245c;
                    font-size:16px;
                    margin-bottom:5px;
                ">
                    Dr. Robert Wilson
                </h3>

                <small style="color:#8c8497;">
                    Neurologist
                </small>

            </div>

        </div>


        <p style="
            color:#827990;
            font-size:13px;
            margin-bottom:15px;
        ">
            Treats neurological conditions involving the
            brain, spinal cord and nervous system.
        </p>


        <div style="
            border-top:1px solid #eeeaf3;
            padding-top:14px;
            margin-bottom:15px;
        ">

            <strong style="
                color:#403464;
                font-size:12px;
            ">
                Department
            </strong>

            <p style="
                color:#827990;
                font-size:12px;
                margin-top:4px;
            ">
                Neurology
            </p>

        </div>


        <a href="/doctors/3"
           style="
           color:#7357c7;
           text-decoration:none;
           font-size:12px;
           font-weight:bold;
           ">
            View Profile →
        </a>

    </div>


</div>


<div class="panel" style="margin-top:22px;">

    <div class="panel-header">

        <h3>Doctor Availability</h3>

        <a href="/doctors/create">
            Manage Staff →
        </a>

    </div>


    <table>

        <thead>

            <tr>
                <th>Doctor</th>
                <th>Specialization</th>
                <th>Department</th>
                <th>Availability</th>
            </tr>

        </thead>


        <tbody>

            <tr>

                <td class="patient">
                    Dr. Michael Brown
                </td>

                <td class="doctor">
                    Cardiology
                </td>

                <td>
                    Cardiology
                </td>

                <td>
                    <span class="badge confirmed">
                        Available
                    </span>
                </td>

            </tr>


            <tr>

                <td class="patient">
                    Dr. Emily Davis
                </td>

                <td class="doctor">
                    Pediatrics
                </td>

                <td>
                    Pediatrics
                </td>

                <td>
                    <span class="badge confirmed">
                        Available
                    </span>
                </td>

            </tr>


            <tr>

                <td class="patient">
                    Dr. Robert Wilson
                </td>

                <td class="doctor">
                    Neurology
                </td>

                <td>
                    Neurology
                </td>

                <td>
                    <span class="badge waiting">
                        On Leave
                    </span>
                </td>

            </tr>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital-management-system\resources\views/doctors/index.blade.php ENDPATH**/ ?>